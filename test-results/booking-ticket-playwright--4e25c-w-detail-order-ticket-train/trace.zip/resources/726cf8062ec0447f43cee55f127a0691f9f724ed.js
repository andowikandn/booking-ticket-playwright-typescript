$('.number').keypress(function(e) {
    var regex = new RegExp("^[0-9.\b]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.letter').keypress(function(e) {
    var regex = new RegExp("^[a-zA-Z \b]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.userName').keypress(function(e) {
    var regex = new RegExp("^[a-zA-Z0-9_.\b]*$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.alfanumeric').keypress(function(e) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.genInfo').keypress(function(e) {
    var regex = new RegExp("^[a-zA-Z0-9. /,()\b\_]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.email').keypress(function(e) {
    var regex = new RegExp("^[a-zA-Z0-9_.@\b\-]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });

$('.onlyNumber').keypress(function(e) {
    var regex = new RegExp("^[0-9\b]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    var key = e.keyCode || e.which;
    // tab &, Delete keys
    if(key == 9 || key == 46) { 
     return;
    }
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
    });