let APP = {
    initSelect2: function(){
        $('.select2').select2({
            tags: true,
            placeholder: "Ketik atau pilih nama sesuai KTP/SIM/Paspor"
        });
    },

    showDate: function(day = false){
        if(day) {
            day = APP.convertToEng(day);
            day = day.replace(/-/g, ' ');
        }

        // var today = new Date();
        var today = (day ? new Date(day) : new Date());
        var d =today.getDay();
        var dd =today.getDate();
        var mm =today.getMonth(); //January is 0!
        var yyyy = today.getFullYear();

        if (day){
            today = arr_hari[d]+ ', ' +dd + ' ' + arr_bulan[mm] + ' ' + yyyy;
        } else {
            today = dd + ' ' + arr_bulan[mm] + ' ' + yyyy;
        }
        $('.today').prepend(today);
    },

    formatDate: function(date, show_day=false, conector = '-'){
        var dateConector = date.slice(2,3);
        if ( dateConector == '-'){
            var today = new Date(date);
        } else {
            date = date.toString();
            var year = date.slice(0,4);
            var month = date.slice(5,7);
            month = month - 1;
            var day = date.slice(8,10);
            today = new Date(year, month, day);
        }
        var d =today.getDay();
        var dd =today.getDate();
        var mm =today.getMonth(); //January is 0!
        var yyyy = today.getFullYear();
        dd = dd < 10? '0'+dd: dd;

        if (show_day == true){
            today = arr_hari[d]+ ', ' +dd + conector + arr_bulan[mm] + conector + yyyy;
        } else {
            today = dd + conector + arr_bulan[mm] + conector + yyyy;
        }
        return today;
    },

    initDate: function(param = null, initdate = '2019,8,01', holidays = null){
        let defdate = new Date() > new Date(initdate) ? 0 : new Date(initdate);
        if (param){
            param = param.replace(/-/g," ");
        }
        let newdate = (param ? new Date(param) : param);
        let holiDays = holidays;

        $(".date_picker").datepicker({
            format: "dd-MM-yyyy",
            dateFormat: "dd-MM-yy",/**for jquery ui */
            monthNames: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"],
            autoclose: true,
            todayHighlight: true,
            defaultDate: "03-11-2015",
            numberOfMonth2: 2
        });

        $("#departure_dateh").datepicker({
            dateFormat: "dd-MM-yy",
            format: "dd-MM-yyyy",
            monthNames: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"],
            autoclose: true,
            numberOfMonth2: 2,
            changeMonth: true,
            changeYear: true,
            minDate: defdate,
            maxDate: 91,
            beforeShowDay : function (date) {
                for (i = 0; i < holiDays.length; i++) {
                    if (date.getMonth() == holiDays[i][0] - 1
                         && date.getDate() == holiDays[i][1]) {
                       return [true, 'holiday', holiDays[i][2]];
                    }
                  }
                 return [true, ''];
            }
        });

        $("#departure_dateh").datepicker("setDate", (newdate ? newdate : new Date()));

        //member/user birth date
        let currentMonth = new Date();
        let currentMonthNum = currentMonth.getMonth();
        let currentDayNum = currentMonth.getDate()-1;
        $("#member_tanggallahir, #member_birthdate").datepicker({dateFormat: "dd-MM-yy",/**for jquery ui */
            format: "dd-MM-yyyy",
            monthNames: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"],
            yearRange: "-100:+0",
            autoclose: true,
            todayHighlight: true,
            numberOfMonth2: 2,
            changeMonth: true,
            changeYear: true,
            // maxDate: "-"+currentDayNum+"d -"+currentMonthNum+"m -3Y",
            maxDate: "today"
        });
        $("#member_tanggallahir").datepicker("setDate", (newdate ? newdate : new Date()));
        $("#member_birthdate").datepicker("setDate", (newdate ? newdate : new Date()));
    },

    copyData: function()
    {
        $('input[name=copy]').change(function(){
            // var date = $('#pemesan_tanggallahir').val();
            // date = APP.formatDate(date);
            // date = date.replace('--', '-');

            if ($('input[name=copy]').is(':checked')){
                $('#penumpang_title1').val($('#pemesan_title').val());
                $('#penumpang_tandapengenal1').val($('#pemesan_tandapengenal').val());
                // $('#penumpang_tanggallahir1').val(date);
                // $('#penumpang_nama1').append('<option value="'+$('#pemesan_nama').val()+'" selected>'+$('#pemesan_nama').val()+'</option');
                $('#penumpang_nama1').val($('#pemesan_nama').val());
                $('#penumpang_notandapengenal1').val($('#pemesan_notandapengenal').val());
                $('#penumpang_nohp1').val($('#pemesan_nohp').val());
            } else {
                $('#penumpang_tanggallahir1').val('');
                $('#penumpang_nama1 option[value="'+$('#pemesan_nama').val()+'"]').remove();
                $('#penumpang_nama1').val('');
                $('#penumpang_title1').val('MR');
                $('#penumpang_tandapengenal1').val('ktp');
                $('#penumpang_notandapengenal1').val('');
                // $('#penumpang_nohp1').val('');
            }
        });
    },

    addPassengerVal: function(element) {
        $(element).click(function(e){
            e.preventDefault();

            var fieldName = $(this).attr('data-field');
            var mytype = $(this).attr('data-type');

            // var input = $("input[name='"+fieldName+"']");
            var input = $("#"+fieldName);
            var currentVal = parseInt(input.val());
            if(!isNaN(currentVal)){
                if(mytype == "minus"){
                    var minVal = parseInt(input.attr('min'));

                    if(currentVal > minVal){
                        input.val(currentVal - 1).change();
                    }

                }else if(mytype == 'plus'){
                    var maxVal = parseInt(input.attr('max'));
                    if(currentVal < maxVal){
                        input.val(currentVal + 1).change();
                    }
                }
            }
        });
    },

    filterSchedule: function() {
        //uncheck all checkbox if another filter is clicked
        $('.btn-check').click(function() {
            $('.checkbox').prop('checked', false);
            $('.list-kereta').show();
        });

        //toggle div
        $('.btn-class').on('click',function(e){
            e.preventDefault();
            $('.view-filter').hide();
            $('.sort-class').toggle();
        });
        $('.btn-stasiun').on('click',function(e){
            //e.preventDefault();
            $('.view-filter').hide();
            $('.sort-stasiun').show();
        });
        $('.btn-kereta').on('click',function(e){
            //e.preventDefault();
            $('.view-filter').hide();
            $('.sort-kereta').show();
        });
        $('.btn-waktu').on('click',function(e){
            //e.preventDefault();
            $('.view-filter').hide();
            $('.sort-time').show();
        });
        $('.btn-harga').on('click',function(e){
            e.preventDefault();
            $('.view-filter').hide();
            $('.sort-harga').toggle();
        });

        //show data by checkbox
        $(document).on('change','.checkbox',function(){
            $('.list-kereta').hide();
            var lenghtCheckbox= $('.checkbox:checked').length;
            if(lenghtCheckbox > 0){
                $('.checkbox').each(function(){
                    if(this.checked==true){
                        var value=$(this).val();
                        $('.list-kereta').each(function(){
                            if($(this).attr('data-class')==value)
                            {
                                $(this).show();
                            }
                            if($(this).attr('data-stasiun')==value)
                            {
                                $(this).show();
                            }
                            if($(this).attr('data-kereta')==value)
                            {
                                $(this).show();
                            }
                            if($(this).attr('data-time')==value)
                            {
                                $(this).show();
                            }
                            if($(this).attr('data-harga')==value)
                            {
                                $(this).show();
                            }
                        });
                    }
                })
            }else{
                $('.list-kereta').show();
            }
        });
    },

    enableSubmitPassengerData: function(){
        $('input[name=agree]').change(function(){
            var capchta = localStorage.getItem("captcha");
            if(this.checked==true && capchta != undefined && capchta == 1){
                $('#bayar').attr('disabled', false);
            } else {
                $('#bayar').attr('disabled', true);
            }
        });
    },

    validatePassengerData: function(infant_birth=null)
    {
        $('#bayar').click(function(){
            $("#submitConfirm").modal('show');
        })
        $('#mSubmit').click(function(){
            $("#submitConfirm").modal('toggle');
            $('#pesanan').submit();
        })

        //validate infant birth date
        let maximalInfantDate = new Date();
        if(infant_birth) {
            maximalInfantDate = new Date(infant_birth);
        }
        let minimalInfantDate = (maximalInfantDate.getFullYear()-3) +'-'+ (maximalInfantDate.getMonth()+1) +'-'+ maximalInfantDate.getDate();

        $(".infant_tanggallahir").datepicker({dateFormat: "dd-MM-yy",/**for jquery ui */
            format: "dd-MM-yyyy",
            monthNames: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"],
            autoclose: true,
            todayHighlight: true,
            numberOfMonth2: 2,
            changeMonth: true,
            changeYear: true,
            minDate: new Date(minimalInfantDate),
            maxDate: maximalInfantDate
        });
        // $(".infant_tanggallahir").datepicker("setDate", new Date(maximalInfantDate));

        $("#pesanan").submit(function(){
            //e.preventDefault();
            var x = "";
            var arrinput = [];
            //alert("Submit yeah!!");
            $(".uniqueval").each(function(){

                x = $(this).val();
                arrinput.push(x);
            });

            function checkDuplicate(arr){
                var counts = [];
                for(var i = 0;i <= arr.length; i++){
                    if(counts[arr[i]] === undefined){
                        counts[arr[i]] = 1;
                    }else{
                        return arr[i];
                    }
                }
                return false;
            }

            var noHp = checkDuplicate(arrinput);
            if(noHp){
                $("#modalDuplicateError").modal("show");
                $("[data-val="+noHp+"]").parent(".input-group").addClass("has-error has-danger");
                return false;
            }
            return true;
       });

       $('.uniqueval').bind('change', function(){
           var data = $(this).val();
           $(this).attr('data-val', data);

           if ($(this).parents().hasClass('has-error has-danger')){
                $(this).parents().removeClass('has-error has-danger')
           }
        });
    },

    applyPassData_old: function(data)
    {
        // data = JSON.parse(data);
        $('.passenger').change(function(){
            var count = $(this).find(':selected').data('count');
            var type = $(this).find(':selected').data('type');
            var id = $(this).find(':selected').data('id');

            if (data.length > 0){
                $.each(data, function(key, val){
                    if(id == val.id){
                        if (type == 'A'){
                            if (val.gender == 1){
                                var title = 'tn';
                            } else {
                                var title = 'ny';
                            }

                            if (val.idtype == 1){
                                var idtype = 'ktp';
                            } else if (val.idtype == 2){
                                var idtype = 'sim';
                            } else if (val.idtype == 3){
                                var idtype = 'paspor';
                            } else {
                                var idtype = 'infant';
                            }

                            var brithdate = APP.formatDate(val.birthdate,false, '-');
                            $('#penumpang_title'+count).val(title);
                            $('#penumpang_tandapengenal'+count).val(idtype);
                            $('#penumpang_tanggallahir'+count).val(brithdate);
                            // $('#penumpang_nama'+count).append('<option value="'+fullname+'" selected>'+fullname+'</option');
                            $('#penumpang_notandapengenal'+count).val(val.idnumber);
                            $('#penumpang_nohp'+count).val($('#pemesan_nohp').val());
                        } else {
                            $('#infant_tanggallahir'+count).val(brithdate);
                        }
                    }
                });
            }
        });
    },

    setCategoryId: function(){
        var cat_id = $('li.active').children().data('id');
        $('input[name=cat_id]').val(cat_id);

        $('.cat_id').click(function(){
            $('input[name=cat_id]').val($(this).data('id'));
        });
    },

    countDown: function(ex_date){
        var countDownDate = new Date(ex_date).getTime();

        // Update the count down every 1 second
        var x = setInterval(function() {

        // Get today's date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // // Output the result in an element with id="demo"
        // document.getElementById("countdown").innerHTML = hours + "Jam "
        // + minutes + "Menit " + seconds + "Detik ";
        var h = "0"+hours;
        var m = "0"+minutes;
        var s = "0"+seconds;
        document.getElementById("countdown").innerHTML = (h.slice(-2)) + ":"
        + (m.slice(-2)) + ":" + (s.slice(-2));

        // If the count down is over, write some text
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("countdown").innerHTML = "EXPIRED";
        }
        }, 1000);
    },

    applyPassData: function(data)
    {
        let buttonNum = 0;
        $('.btn-pop-adult').click(function() {
            buttonNum = $(this).attr('data-num');
            $('#popup-adult').modal('show');
        });
        $('.btn-pop-infant').click(function() {
            buttonNum = $(this).attr('data-num');
            $('#popup-infant').modal('show');
        });

        // data = JSON.parse(data);
        $('.passenger-option').click(function(){
            
            var count = $(this).attr('data-count');
            var type = $(this).attr('data-type');
            var id = $(this).attr('data-id');
            var fullname = $(this).attr('data-fullname');
            // if (data.length > 0){
                $.each(data, function(key, val){
                    let birthdate = APP.formatDate(val.birthdate, false, '-');
                    if(id == val.id){
                        if (type == 'A'){
                            if (val.gender == 1){
                                var title = 'MR';
                            } else {
                                var title = 'MRS.';
                            }
                            if (val.idtype == 1){
                                var idtype = 'ktp';
                            } else if (val.idtype == 2){
                                var idtype = 'sim';
                            } else if (val.idtype == 3){
                                var idtype = 'paspor';
                            } else if (val.idtype == 4){
                                var idtype = 'lainnya';
                            } else {
                                var idtype = 'infant';
                            }

                            $('#penumpang_title'+buttonNum).val(title);
                            $('#penumpang_tandapengenal'+buttonNum).val(idtype);
                            $('#penumpang_notandapengenal'+buttonNum).attr('data-val', val.idnumber);
                            $('#penumpang_tanggallahir'+buttonNum).val(birthdate);
                            $('#penumpang_nama'+buttonNum).val(fullname);
                            // $('#penumpang_nama'+count).append('<option value="'+fullname+'" selected>'+fullname+'</option');
                            $('#penumpang_notandapengenal'+buttonNum).val(val.idnumber);
                            // $('#penumpang_nohp'+count).val($('#pemesan_nohp').val());
                        } else {

                            if (val.idtype == 1){
                                var idtype = 'ktp';
                            } else if (val.idtype == 3){
                                var idtype = 'paspor';
                            }

                            $('#infant_nama'+buttonNum).val(fullname);
                            $('#infant_tanggallahir'+buttonNum).val(birthdate);
                            $('#infant_tandapengenal'+buttonNum).val(idtype);
                            $('#infant_notandapengenal'+buttonNum).val(val.idnumber);
                        }
                    }
                });
            // }
        });
    },

    defaultSeat: function(paxes){
        console.log('PAXES : ', paxes)
        $.each(paxes, function(key, val){
            var col = val.wagondetcol;
            var row = val.wagondetrow;
            var gerbong = val.stamformdetcode;
            var param = "[data-gerbang="+col+"][data-row="+row+"][data-type-kereta="+gerbong+"]";
            var number = key+1;

            $(param).removeClass('filled'); /**hapus class filled */
            $(param).addClass('numseat-color active').attr('data-active', 1).attr('data-passenger', number).text('P'+ number);
            $('li.p'+key).html(gerbong+','+row+col);

            $("#sel1").val(gerbong);
            var slickGoTo  = $('#sel1 option:selected').attr('data-row');
            $('.content-column-sheet').slick('slickGoTo', slickGoTo);
        });

        $('#resetSeat').click(function(){
            $('.seat.active').removeClass('active').text('');
            $.each(paxes, function(key, val){
                var col = val.wagondetcol;
                var row = val.wagondetrow;
                var gerbong = val.stamformdetcode;
                var param = "[data-gerbang="+col+"][data-row="+row+"][data-type-kereta="+gerbong+"]";
                var number = key+1;

                $(param).removeClass('filled'); /**hapus class filled */
                $(param).addClass('numseat-color active').attr('data-active', 1).attr('data-passenger', number).text('P'+ number);
                $("#sel1").val(gerbong);
                var slickGoTo  = $('#sel1 option:selected').attr('data-row');
                $('.content-column-sheet').slick('slickGoTo', slickGoTo);
            });
        })
    },
    
    preventBack: function(state = 'passengercontrol'){
            if (window.history && window.history.pushState) {

                let loop = 10;
            for (i = 0; i < loop; i++) {
              window.history.pushState('forward', null, BASE_URL+state);
            }

              $(window).on('popstate', function() {
                window.location.assign('/' + state);
              });

            }
    },

    selectSeat: function(){

        $('.cehck-passenger').on('click',function(){
            var passager = $(this).attr('data-passenger');
            $('.radio-type-kereta').attr('data-passenger',passager);
        });

        $('.seat').on('click',function(){
            var passager = $('.cehck-passenger');
            if(passager!=''){
                var class_filled = $(this).hasClass("filled");
                var class_not = $(this).hasClass("not");
                // var typeKereta = $(".radio-type-kereta option:selected").val();
                var typeKereta = $(this).attr('data-type-kereta');
                var dataActive= $(this).attr('data-active');
                var dataSeat = $(this).attr('data-row');
                var datagerbong =$(this).attr('data-row')+''+ $(this).attr('data-gerbang');
                $('.seat').each(function(){
                    if(class_filled == false && class_not == false){
                        if($(this).attr('data-passenger')==passager){
                            $(this).removeClass('active');
                            $(this).html(' ');
                            $(this).attr('data-active','0');
                            $(this).attr('data-passenger','0');
                        }
                    }

                });
                if(class_filled == false && class_not == false){
                    if(dataActive==1){
                        $(this).removeClass('active');
                        $(this).html(' ');
                        $(this).attr('data-active','0');
                        $(this).attr('data-passenger','0');
                    }else{
                        $(this).addClass('active');
                        $(this).html('P'+passager);
                        $(this).attr('data-active','1');
                        $(this).attr('data-passenger',passager);
                        //$('.col-passenger.active').find('.type-kereta').html(typeKereta);
                        //$('.col-passenger.active').find('.seat-gerbong').html(datagerbong);
                        $('.col-passenger.active').find('.type-kereta').val(typeKereta);
                        $('.col-passenger.active').find('.seat-gerbong').val(datagerbong);
                    }
                }
            }else{
                //alert("Mohon klik kotak Penumpang yang ingin dipindahkan.");
                $("#modalSeatError").modal("show");
            }

        });
    },

    submitSeat: function(){
        $('#sSubmit').click(function(){
            $("#submitConfirmSeat").modal('toggle');
            $('#payment').submit();
        });

        $('#confirmSeat').click(function(){
            $("#submitConfirmSeat").modal('toggle');
        })
    },

    convertToEng: function(date=null, format=null){
        let result, array_date, date_index, arr_res;
        if(!date) {
            date = new Date();
            date =  date.getFullYear() + '-' + date.getMonth() + '-' + date.getDate();
            engDate = new Date(date);
            result = engDate.getDate() + '-' + arr_bulan[(engDate.getMonth()+1)] + '-' + engDate.getFullYear();
        } else {
            array_date = date.split('-');
            date_index = arr_bulan.indexOf(array_date[1]);
            result = array_date[0] + '-' + arr_english_month[date_index] + '-' + array_date[2];
        }

        switch(format) {
            case 'Y-m-d':
                arr_res = result.split('-');
                result = arr_res[2] +'-'+ (arr_english_month.indexOf(arr_res[1])+1) +'-'+ arr_res[0];
            break;

            default:
                result = result;
        }

        return result;
    },

    cancelBooking:function() {
        $('#cancelSubmit').click(function(){
            $("#cancelBook").modal('toggle');
            $('#cbook').submit();
        });
    },

    callModalCancel:function() {
        $('#buttonCancel').click(function(){
            $("#cancelBook").modal('toggle');
        })
    },

    initPasSeatSlick:function() {
        $('.content-column-sheet').slick({
            dots: false,
            prevArrow: '<div class="prev"><i class="fas fa-chevron-left"></i></div>',
            nextArrow: '<div class="next"><i class="fas fa-chevron-right"></i></div>'
        });
    },

    slickChange:function() {
        $('#vertical .slider').on('afterChange', function() {
            var activeOpt = $('#vertical .slick-active').children('.table-cols-wrapper').attr('data-kereta');
            $("#sel1").val(activeOpt);
        });

        $('#horizontal .slider').on('afterChange', function() {
            var activeOpt = $('.slick-active').children('.table-cols-wrapper').attr('data-kereta');
            $("#sel1").val(activeOpt);
        });

        $(document).on('change','.radio-type-kereta',function(){
            var typeKereta = $(this).val();
            var slickGoTo  = $('option:selected', this).attr('data-row');
            passager = $(this).attr('data-passenger');

           // $('.col-passenger.active').find('.type-kereta').html(typeKereta);
            $('.content-column-sheet').slick('slickGoTo', slickGoTo);

        });

        $(document).ready(function(){
            var slickGoTo  = $('option:selected', this).attr('data-row');
            $('.content-column-sheet').slick('slickGoTo', slickGoTo);
        });
    },

    payment:function(data){
        // data = JSON.stringify(data);
        var win = window.open(data, '_blank');
        win.focus();
    },

    modifyIdNum: function(element_setter, element_target) {
        //modify attribute on id number by id type
        $(document).on('change', element_setter, function() {
            let idtype = $(this).val();
            let lower = idtype.toLowerCase();

            $(element_target).val('');
            $(element_target).attr('minlength', 1);
            $(element_target).removeAttr('readonly');

            switch(lower) {
                case 'ktp':
                case '1':
                    $(element_target).attr('maxlength', 16);
                    $(element_target).parent().parent().removeClass('info');
                    break;

                case 'sim':
                case '2':
                    $(element_target).attr('minlength', 9);
                    $(element_target).attr('maxlength', 12);
                    $(element_target).parent().parent().removeClass('info');
                    break;

                case 'paspor':
                case '3':
                    $(element_target).attr('minlength', 5);
                    $(element_target).attr('maxlength', 9);
                    $(element_target).parent().parent().removeClass('info');
                    break;

                case 'lainnya':
                case '4':
                    $(element_target).attr('minlength', 5);
                    $(element_target).attr('maxlength', 25);
                    $(element_target).parent().parent().addClass('info');
                    break;

                case 'infant':
                case '5':
                    $(element_target).attr('maxlength', 8);
                    $(element_target).val('-');
                    $(element_target).attr('readonly', 'readonly');
                    $(element_target).parent().parent().removeClass('info');
                    break;

                default:
                    $(element_target).attr('maxlength', 8);
            }
        });
    },

    checkAge: function() {
        $('#member_birthdate').change( function() {
            var date = $(this).val();

            date = APP.convertToEng(date);

            date = date.replace(/-/g, ' ');

            var bornDate = new Date(date).getTime();

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = now - bornDate;

            // Time calculations for days, hours, minutes and seconds
            var days = (distance / (1000 * 60 * 60 * 24 * 365));

            if (days > 3){
                $('#radio-adult').prop('checked', 'checked');
                $('#radio-infant').attr('disabled', 'disabled');
            }
        });

        $(document).ready(function(){
            var date = $('#member_birthdate').val();

            date = APP.convertToEng(date);

            date = date.replace(/-/g, ' ');

            var bornDate = new Date(date).getTime();

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = now - bornDate;

            // Time calculations for days, hours, minutes and seconds
            var days = (distance / (1000 * 60 * 60 * 24 * 365));

            if (days > 3){
                $('#radio-adult').prop('checked', 'checked');
                $('#radio-infant').attr('disabled', 'disabled');
            }
        });
    },

    setMaxLength: function (){
        $('#pemesan_tandapengenal').change(function() {
            var val = $(this).val();
            $('#pemesan_notandapengenal').val('');
            if (val == 'ktp'){
                $('#pemesan_notandapengenal').attr('maxLength', '16');
                $('#pemesan_notandapengenal').parent().parent().removeClass('info');
            } else if (val == 'paspor') {
                $('#pemesan_notandapengenal').attr('maxLength', '9');
                $('#pemesan_notandapengenal').parent().parent().removeClass('info');
            } else if (val == 'sim') {
                $('#pemesan_notandapengenal').attr('maxLength', '12');
                $('#pemesan_notandapengenal').parent().parent().removeClass('info');
            } else if (val == 'lainnya') {
                $('#pemesan_notandapengenal').attr('maxLength', '25');
                $('#pemesan_notandapengenal').parent().parent().addClass('info');
            }
        });
        $('#penumpang_tandapengenal1').change(function() {
            var val = $(this).val();
            $('#penumpang_notandapengenal1').val('');
            if (val == 'ktp'){
                $('#penumpang_notandapengenal1').attr('maxLength', '16');
                $('#penumpang_notandapengenal1').parent().parent().removeClass('info');
            } else if (val == 'paspor') {
                $('#penumpang_notandapengenal1').attr('maxLength', '9');
                $('#penumpang_notandapengenal1').parent().parent().removeClass('info');
            } else if (val == 'sim') {
                $('#penumpang_notandapengenal1').attr('maxLength', '12');
                $('#penumpang_notandapengenal1').parent().parent().removeClass('info');
            } else if (val == 'lainnya') {
                $('#penumpang_notandapengenal1').attr('maxLength', '25');
                $('#penumpang_notandapengenal1').parent().parent().addClass('info');
            }
        });
        $('#penumpang_tandapengenal2').change(function() {
            var val = $(this).val();
            $('#penumpang_notandapengenal2').val('');
            if (val == 'ktp'){
                $('#penumpang_notandapengenal2').attr('maxLength', '16');
                $('#penumpang_notandapengenal2').parent().parent().removeClass('info');
            } else if (val == 'paspor') {
                $('#penumpang_notandapengenal2').attr('maxLength', '9');
                $('#penumpang_notandapengenal2').parent().parent().removeClass('info');
            } else if (val == 'sim') {
                $('#penumpang_notandapengenal2').attr('maxLength', '12');
                $('#penumpang_notandapengenal2').parent().parent().removeClass('info');
            } else if (val == 'lainnya') {
                $('#penumpang_notandapengenal2').attr('maxLength', '25');
                $('#penumpang_notandapengenal2').parent().parent().addClass('info');
            }
        });
        $('#penumpang_tandapengenal3').change(function() {
            var val = $(this).val();
            $('#penumpang_notandapengenal3').val('');
            if (val == 'ktp'){
                $('#penumpang_notandapengenal3').attr('maxLength', '16');
                $('#penumpang_notandapengenal3').parent().parent().removeClass('info');
            } else if (val == 'paspor') {
                $('#penumpang_notandapengenal3').attr('maxLength', '9');
                $('#penumpang_notandapengenal3').parent().parent().removeClass('info');
            } else if (val == 'sim') {
                $('#penumpang_notandapengenal3').attr('maxLength', '12');
                $('#penumpang_notandapengenal3').parent().parent().removeClass('info');
            } else if (val == 'lainnya') {
                $('#penumpang_notandapengenal3').attr('maxLength', '25');
                $('#penumpang_notandapengenal3').parent().parent().addClass('info');
            }
        });
        $('#penumpang_tandapengenal4').change(function() {
            var val = $(this).val();
            $('#penumpang_notandapengenal4').val('');
            if (val == 'ktp'){
                $('#penumpang_notandapengenal4').attr('maxLength', '16');
                $('#penumpang_notandapengenal4').parent().parent().removeClass('info');
            } else if (val == 'paspor') {
                $('#penumpang_notandapengenal4').attr('maxLength', '9');
                $('#penumpang_notandapengenal4').parent().parent().removeClass('info');
            } else if (val == 'sim') {
                $('#penumpang_notandapengenal4').attr('maxLength', '12');
                $('#penumpang_notandapengenal4').parent().parent().removeClass('info');
            } else if (val == 'lainnya') {
                $('#penumpang_notandapengenal4').attr('maxLength', '25');
                $('#penumpang_notandapengenal4').parent().parent().addClass('info');
            }
        });
    }, 

    widthControl: function() {
        $(window).on('resize', function() {
            if (window.innerWidth < 746){
                $('#vertical').show();
                $('#horizontal').hide();
            } else {
                $('#vertical').hide();
                $('#horizontal').show()
            }

            if (window.innerWidth < 451){
                $('#resetSeat').addClass('col-xs-12');
                $('#confirmSeat').addClass('col-xs-12');
            } else {
                $('#resetSeat').removeClass('col-xs-12');
                $('#confirmSeat').removeClass('col-xs-12');
            }
        });
        $(window).on('load', function() {
            if (window.innerWidth < 746){
                $('#vertical').show();
                $('#horizontal').hide();
            } else {
                $('#vertical').hide();
                $('#horizontal').show()
            }

            if (window.innerWidth < 451){
                $('#resetSeat').addClass('col-xs-12');
                $('#confirmSeat').addClass('col-xs-12');
            } else {
                $('#resetSeat').removeClass('col-xs-12');
                $('#confirmSeat').removeClass('col-xs-12');
            }
        });
    },

    showPassword: function () {
        $('.pass + .glyphicon').on('click', function() {
            $(this).toggleClass('glyphicon-eye-close').toggleClass('glyphicon-eye-open'); // toggle our classes for the eye icon
            // $('.pass').togglePassword(); // activate the hideShowPassword plugin
            let type = $('.pass').attr('type');
            var change = type == 'password' ? "text" : "password";
             $('.pass').each(function() {
                $("<input type='"+change+"' class ='"+$(this).attr("class")+"' placeholder ='"+$(this).attr("placeholder")+"'/>").attr({ name: this.name, value: this.value, class: this.class }).insertBefore(this);
                $(this).remove()
            });
        });

        $('.cpass + .glyphicon').on('click', function() {
            $(this).toggleClass('glyphicon-eye-close').toggleClass('glyphicon-eye-open'); // toggle our classes for the eye icon
            // $('.cpass').togglePassword(); // activate the hideShowPassword plugin
            let type = $('.cpass').attr('type');
            var change = type == 'password' ? "text" : "password";
             $('.cpass').each(function() {
                $("<input type='"+change+"' class ='"+$(this).attr("class")+"' placeholder ='"+$(this).attr("placeholder")+"'/>").attr({ name: this.name, value: this.value, class: this.class }).insertBefore(this);
                $(this).remove()
            });
        });
    },

    initDatalist: function(link){
        $('#member_kota').flexdatalist({
            minLength: 2,
            valueProperty: 'code',
            selectionRequired: true,
            visibleProperties: ["name"],
            searchIn: ['name'],
            data: link
        });
    },

    noAllowType: function(){
        $('.no-type').keydown(function() {
            //code to not allow any changes to be made to input field
            return false;
          });
    }
}

function userLogging(data) {
    $.ajax({
        type:'POST',
        data: data,
        url: '/api/user-logging',
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        success:function(data){
            // $("#msg").html(data.msg);
        }
    });
}

let arr_bulan = ["Januari",
            "Februari",
            "Maret",
            "April",
            "Mei",
            "Juni",
            "Juli",
            "Agustus",
            "September",
            "Oktober",
            "November",
            "Desember"];
let arr_hari = [
    "Minggu",
    "Senin",
    "Selasa",
    "Rabu",
    "Kamis",
    "Jumat",
    "Sabtu"];

let arr_english_month = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
];